<?php

	require_once 'classes/connection.php';
	require_once 'classes/Movie.php';
	require_once 'classes/Genre.php';
	require_once 'classes/DB.php';
